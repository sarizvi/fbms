!#/bin/bash
java -Dawt.useSystemAAFontSettings=on -jar fbms.jar
exit
