-------------------------------------------------------------------------------
                FBMS: File Backup and Management System
-------------------------------------------------------------------------------
    Copyright (C) 2013 Group 06: Hoffert, Rizvi, Alsharif, Tao, and Butler

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

FBMS is an automated backup system written in Java. It keeps track of file
changes and stores older revisions of files.

FBMS works on Windows and Linux (Mac untested).

RUNNING THE PROGRAM (pre-built distribution only):
  - Unzip the "fbms-distribution.zip" file
  - Windows users can run the "run.cmd" file (either double click it or type
    the name in the command line)
  - Linux and Mac users can run the "run.sh" file via the terminal
  - The working directory must be the directory that the JAR file is in (same
    directory as the "run" files are in)

BUILDING WITH ANT:
  - Apache Ant is required: https://ant.apache.org/
  - Building with ant will create a folder named "build" with the
    distribution package (binaries, libraries, and the necessary files
    for distributing the program) and a zip file with the contents of the
    build folder.
  -  To build the distribution package with debugging enabled, use
     "ant" or "ant debug".
  - "ant release" will build without debugging.
  - "ant clean" will remove all files created by ant.

ECLIPSE DEVELOPMENT:
  - Eclipse is required: http://www.eclipse.org/
  - In Eclipse, go to File > Import
  - Under "General", choose "Existing Projects into Workspace"
  - As the root directory, choose the folder containing this file, which
    should also contain a file named ".classpath" and a file named
    ".project"
  - Leave everything else at the default and choose "finish". The project
    should now be imported into the package explorer.
  - To verify the importation was successful, attempt to run the program.