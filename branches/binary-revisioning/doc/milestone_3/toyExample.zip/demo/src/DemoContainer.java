// ==============================================================
//	This file is part of FBMS (https://code.google.com/p/fbms)
//
//	Copyright (C) 2013 Group 06
//
//	You can redistribute this code and/or modify it under
//	the terms of the GNU General Public License as published
//	by the Free Software Foundation; either version 3 of the
//	License, or (at your option) any later version
// ==============================================================

class DemoContainer
{
	// Just a plain old data class for grouping together multiple values in a list
	public int id;
	public String name;
}